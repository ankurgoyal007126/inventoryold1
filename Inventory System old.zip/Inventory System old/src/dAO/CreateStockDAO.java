package dAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import dTO.CreateStockDTO;

public class CreateStockDAO {
	public boolean CreateStockDAO(CreateStockDTO stockDTO) throws SQLException, ClassNotFoundException {
	
	boolean result = false;
    Connection con = null;
	
    System.out.println("======"+stockDTO.toString());
    
	PreparedStatement pstmt1 =null;
	try 
	{
		con = CommonDAO.getConnection();
		con.setAutoCommit(false);
		pstmt1=con.prepareStatement(CommonSQL.CREATE_STOCK_SQL);
		pstmt1.setString(1,stockDTO.getPcode() );
		pstmt1.setString(2,stockDTO.getPname() );
		pstmt1.setInt(3,stockDTO.getQuantity() );
		pstmt1.setString(4,stockDTO.getPdescription() );
		int noOfRowsEffected1 = pstmt1.executeUpdate();
		if(noOfRowsEffected1>0)
		{	
			con.commit();
			result=true;	
		}
		else
		{
				con.rollback();
				System.out.println("Contact could not be created");
		}
		
		
		
		
		
	}
	finally {
		if(pstmt1!=null)
		{
			pstmt1.close();
		}
		
		if(con!=null)
		{
			con.close();
		}
	}
	return result;
	
	}
	

}
