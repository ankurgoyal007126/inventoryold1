package dTO;

public class ConatctListDTO {
	

}
